﻿import { Link } from 'react-router-dom'
export default function DealsPage(){return <main className="min-h-screen bg-slate-950 p-8 text-slate-100"><Link to="/" className="text-sky-400">Back</Link><h1 className="mt-4 text-3xl font-bold">Deals</h1><p className="mt-3 text-slate-300">Deal management is available through the authenticated API.</p></main>}
