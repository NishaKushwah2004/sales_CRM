﻿import { Link } from 'react-router-dom'
export default function DealDetailPage(){return <main className="min-h-screen bg-slate-950 p-8 text-slate-100"><Link to="/deals" className="text-sky-400">Back to deals</Link><h1 className="mt-4 text-3xl font-bold">Deal</h1></main>}
